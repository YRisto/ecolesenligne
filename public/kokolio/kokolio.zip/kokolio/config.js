/* Réglages de l'outil de pointage (V2).
   Tant que demo vaut true, l'outil fonctionne avec des données d'exemple,
   sans connexion Microsoft. Passez-le à false une fois les champs remplis. */
window.POINTAGE_CONFIG = {
  demo: true,

  // Logo affiché dans l'en-tête, sur l'accueil et l'écran de connexion.
  // Mettez de préférence un fichier déposé à côté de index.html (ex. "logo.png"). Laissez "" pour ne rien afficher.
  logo: "https://www.centre-europeen-formation.fr/wp-content/uploads/2025/08/Logo_CEF.png",
  logoAlt: "Centre Européen de Formation",

  // Identifiants de l'application enregistrée dans Microsoft Entra (voir GUIDE-INSTALLATION.md)
  clientId: "00000000-0000-0000-0000-000000000000",
  tenantId: "00000000-0000-0000-0000-000000000000",

  // Site SharePoint qui stocke les données
  sharepointHost: "votreentreprise.sharepoint.com",
  sitePath: "/sites/Pointage",

  // Identifiants Microsoft des personnes RH : elles voient, valident, clôturent et exportent tout
  rh: ["rh@votreentreprise.fr"],

  // Responsable utilisé quand ni l'annuaire Microsoft ni la fiche salarié n'en indiquent
  managerParDefaut: "rh@votreentreprise.fr",

  // Pause déduite automatiquement quand une journée de plus de pauseSeuilH heures ne comporte aucune pause pointée
  pauseMin: 45,
  pauseSeuilH: 6,

  // Congés payés acquis par mois complet (en jours ouvrés)
  cpParMois: 2.08,

  // Nombre de jours du forfait annuel des cadres au forfait jours
  forfaitJours: 218,

  // Heures annuelles de référence pour les salariés annualisés
  heuresAnnuelles: 1607,

  // Télétravail : nombre maximum de jours par semaine (modifiable par salarié dans sa fiche)
  teletravailMaxSemaine: 2,

  // Compte épargne-temps : nombre maximum de jours de congés payés versés par an
  cetMaxParAn: 10,

  // Congés d'ancienneté : jours ajoutés au solde à partir d'un nombre d'années (à adapter à votre convention collective)
  anciennete: [{ ans: 5, jours: 1 }, { ans: 10, jours: 2 }, { ans: 15, jours: 3 }, { ans: 20, jours: 4 }],

  // Délais d'alerte, en jours, avant une échéance
  alertes: { essai: 30, cdd: 60, visite: 60 },

  // Retard signalé au-delà de cette tolérance par rapport à l'horaire planifié (minutes)
  toleranceRetardMin: 10,

  // Envoi d'e-mails (demande à valider, décision). Nécessite l'autorisation Mail.Send.
  notifications: false,

  motifs: ["Congé payé", "RTT", "Arrêt maladie", "Congé sans solde", "Événement familial", "Formation", "Autre"],
  lieux: ["Bureau", "Télétravail", "Déplacement"],
  activites: ["Activité courante", "Réunion", "Formation", "Rendez-vous extérieur"],

  // Modèles d'horaires proposés dans le planning
  modeles: [
    { nom: "Journée", debut: "09:00", fin: "17:00" },
    { nom: "Matin", debut: "07:00", fin: "14:00" },
    { nom: "Après-midi", debut: "13:00", fin: "20:00" },
    { nom: "Repos" }
  ],

  // Codes Silae : à faire confirmer par la personne qui gère la paie
  silae: {
    heures: "HS-HN",
    absences: {
      "Congé payé": "AB-CP", "RTT": "AB-RTT", "Arrêt maladie": "AB-MAL", "Congé sans solde": "AB-CSS",
      "Événement familial": "AB-EVF", "Formation": "AB-FORM", "Autre": "AB-ABS"
    }
  }
};
