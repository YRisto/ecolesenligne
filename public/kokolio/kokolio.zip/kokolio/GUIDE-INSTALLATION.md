# Outil de pointage et d'absences (V4.3) : guide d'installation

Ce guide s'adresse à la personne qui a les droits d'administration Microsoft 365. Comptez environ une heure.

## Ce que contient le dossier

| Fichier | Rôle |
|---|---|
| `index.html` | L'application (écrans, règles, appels à Microsoft). |
| `config.js` | Les réglages à remplir. C'est le seul fichier à modifier. |
| `msal-browser.min.js` | Bibliothèque officielle Microsoft de connexion (MSAL 4.30.0). |

Le dossier contient aussi les polices (`fonts/`). Pour que le bouton de téléchargement de la page administrateur fonctionne sur votre hébergement, déposez-y également le zip sous le nom `kokolio.zip`.

Il n'y a pas de serveur ni de base de données à installer. Les salariés se connectent avec leur compte Microsoft, et les données sont rangées dans six listes SharePoint de votre Microsoft 365 : `Pointages`, `Absences`, `Salaries`, `Planning`, `Clotures` et `Journal`. Les justificatifs d'absence vont dans le dossier `Justificatifs` de la bibliothèque de documents du site.

Tant que `demo: true` reste dans `config.js`, l'outil tourne avec des données d'exemple et sans Microsoft.

## Étape 1 : créer le site SharePoint

1. Dans SharePoint, créez un **site d'équipe** nommé par exemple `Pointage`. Son adresse ressemblera à `https://votreentreprise.sharepoint.com/sites/Pointage`.
2. Ajoutez tous les salariés concernés comme **Membres** du site (droit de modification).
3. Gardez comme **Propriétaires** uniquement les personnes qui administrent l'outil.

## Étape 2 : enregistrer l'application dans Microsoft Entra

1. Ouvrez le centre d'administration Microsoft Entra, puis **Applications > Inscriptions d'applications > Nouvelle inscription**.
2. Nom : `Pointage`. Types de comptes : **Comptes de cet annuaire uniquement**.
3. URI de redirection : plateforme **Application monopage (SPA)**, avec l'adresse exacte où l'outil est hébergé (par exemple `https://ecolesenligne.fr/kokolio`). Ajoutez aussi la variante avec `www` si le site répond aux deux. L'adresse doit être en HTTPS.
4. Après création, notez l'**ID d'application (client)** et l'**ID de l'annuaire (locataire)**.
5. Dans **Autorisations d'API > Ajouter une autorisation > Microsoft Graph > Autorisations déléguées**, ajoutez :
   - `User.Read` : identité de la personne connectée
   - `User.Read.All` : lecture du responsable hiérarchique dans l'annuaire
   - `Sites.ReadWrite.All` : lecture et écriture dans les listes, dépôt des justificatifs
   - `Sites.Manage.All` : création des listes au premier lancement (peut être retirée ensuite)
   - `Mail.Send` : seulement si vous activez les notifications par e-mail
6. Cliquez sur **Accorder un consentement d'administrateur**.

Les autorisations sont « déléguées » : l'outil ne peut jamais faire plus que ce que la personne connectée a déjà le droit de faire.

## Étape 3 : remplir config.js

Passez `demo` à `false`, puis renseignez `clientId`, `tenantId`, `sharepointHost`, `sitePath`, `rh` et `managerParDefaut`. Les autres réglages ont des valeurs par défaut que vous pouvez ajuster :

| Réglage | Effet |
|---|---|
| `rh` | Identifiants Microsoft des personnes RH : elles voient tout, modifient les fiches, clôturent et exportent. |
| `pauseMin`, `pauseSeuilH` | Pause déduite d'office quand une journée de plus de `pauseSeuilH` heures ne comporte aucune pause pointée. |
| `forfaitJours` | Nombre de jours du forfait annuel des cadres (218 par défaut). |
| `heuresAnnuelles` | Heures de référence des salariés annualisés (1607 par défaut). |
| `teletravailMaxSemaine` | Jours de télétravail autorisés par semaine, modifiable par salarié dans sa fiche. |
| `cetMaxParAn` | Jours de congés payés versables au CET par an. |
| `anciennete` | Barème des congés d'ancienneté, à adapter à votre convention collective. |
| `alertes` | Délais d'alerte avant fin de période d'essai, fin de contrat et visite médicale. |
| `cpParMois` | Congés payés acquis par mois complet (2,08 jours ouvrés par défaut). |
| `toleranceRetardMin` | Marge avant de signaler un retard par rapport au planning. |
| `notifications` | `true` pour envoyer les e-mails (demande à valider, décision, pointage refusé). |
| `motifs`, `lieux`, `activites`, `modeles` | Listes proposées dans les écrans. |
| `silae` | Codes utilisés dans l'export Silae (voir plus bas). |

## Étape 4 : mettre les fichiers en ligne

Déposez les trois fichiers dans un même dossier d'un hébergement web en HTTPS. L'adresse doit correspondre à l'URI de redirection de l'étape 2.

## Étape 5 : premier lancement

1. Ouvrez l'adresse avec un compte **propriétaire du site SharePoint** et connectez-vous.
2. L'écran « Installation » apparaît : cliquez sur **Créer les listes manquantes**.
3. Rechargez la page. L'outil est prêt.

Si la création automatique échoue, créez les listes à la main avec exactement ces noms de colonnes (sans accents). « Long » désigne un texte sur plusieurs lignes.

| Liste | Texte (une ligne) | Long | Nombre |
|---|---|---|---|
| `Pointages` | EmployeEmail, EmployeNom, Jour, Mois, ManagerEmail, Statut, Corrige, Lieu, Activite, ValidePar | Heures, Commentaire, MotifRefus | Minutes |
| `Absences` | EmployeEmail, EmployeNom, Motif, Debut, Fin, DemiJournee, ManagerEmail, Statut, ValidePar, JustificatifNom | Commentaire, MotifRefus, JustificatifUrl | Jours |
| `Salaries` | EmployeEmail, EmployeNom, Equipe, Contrat, DateEntree, JoursTravailles, Matricule, ManagerEmail, Delegue | Details | HeuresHebdo, PauseMin, SoldeCP, SoldeRTT |
| `Planning` | EmployeEmail, ManagerEmail, Semaine | Affectations | |
| `Clotures` | Mois, Statut, CloturePar | | |
| `Journal` | Date, Auteur, Action, Cible | Detail | |

Indexez les colonnes `EmployeEmail`, `ManagerEmail`, `Mois`, `Statut`, `Semaine` et `Delegue`.

## Étape 6 : compléter les fiches salariés

Une fiche se crée à la première connexion de chaque salarié. Les RH la complètent ensuite dans **Équipe > Salariés** : équipe, matricule de paie, contrat, heures par semaine, jours travaillés, pause, report de congés payés, droits RTT.

Le responsable est lu dans le profil Microsoft de chacun (champ **Responsable** du centre d'administration Microsoft 365). S'il est vide, les RH peuvent le saisir dans la fiche.

## Ce que fait l'outil

À l'ouverture, un écran d'accueil propose cinq espaces : salarié non cadre, salarié cadre, manager, RH et administrateur. Chacun n'accède qu'aux espaces qui correspondent à sa fiche et à ses droits (en démonstration, tous sont ouverts). L'espace administrateur, réservé aux RH, liste toutes les fonctionnalités et l'historique des versions. Le bouton « Accueil » de l'en-tête y ramène à tout moment.

Un salarié est « cadre » quand sa fiche indique le contrat **Forfait jours** : il n'a pas de compteur d'heures, mais un décompte des jours travaillés sur le forfait annuel (`forfaitJours` dans `config.js`, 218 par défaut).

- **Salarié** : pointe arrivée et départ avec lieu (bureau, télétravail, déplacement) et activité, suit son compteur débit-crédit, corrige une journée avec motif, demande un congé ou déclare une absence (demi-journée et justificatif possibles), consulte ses soldes et sa vue annuelle jour par jour.
- **Manager** : valide ou refuse pointages et absences, voit les chevauchements dans l'équipe et les alertes légales, tient le planning hebdomadaire, délègue ses validations, consulte la synthèse et la vue annuelle de chacun.
- **RH** : mêmes droits sur tous les salariés, plus les fiches, la clôture mensuelle, l'export Silae et le journal des actions.

### Règles de calcul

- **Horaire prévu** : heures hebdomadaires de la fiche réparties sur les jours travaillés, hors jours fériés et absences validées. Aucun écart n'est calculé pour un forfait jours.
- **Débit-crédit** : heures faites moins horaire prévu, cumulé sur la semaine et le mois, jusqu'à la veille.
- **Alertes légales** : plus de 10 h dans la journée, plus de 48 h dans la semaine, moins de 11 h de repos entre deux journées.
- **À régulariser** : départ non pointé, jour travaillé sans pointage ni absence, retard par rapport au planning.
- **Soldes de congés** : report au 1er janvier + acquisition mensuelle − congés validés de l'année civile. C'est une simplification : la période légale de référence (1er juin au 31 mai) et les règles de votre convention ne sont pas gérées.
- **Jours fériés** : les onze jours fériés de métropole (pas ceux d'Alsace-Moselle ni d'outre-mer).
- **Clôture** : possible une fois le mois terminé et toutes les journées validées. Elle bloque pointages, corrections et validations du mois ; les RH peuvent rouvrir.

### Nouveautés de la V4

- **Organisation du temps** (fiche salarié) : hebdomadaire, cycle de plusieurs semaines (par exemple `39/31`, avec un lundi de départ) ou annualisation avec compteur annuel indicatif.
- **Télétravail** : demande de jours validée par le manager, avec quota hebdomadaire. Ce n'est pas une absence : l'horaire prévu ne change pas.
- **Ancienneté** : calculée depuis la date d'entrée ; les congés d'ancienneté du barème s'ajoutent au solde de congés payés.
- **Compte épargne-temps** : le salarié demande à verser des congés payés sur son CET, puis peut poser des « congés CET ». Les deux passent par la validation du manager.
- **Fiche salarié complète** : identité, poste, contrat, temps de travail, congés, santé au travail. Les informations ajoutées en V4 sont rangées dans la colonne `Details` de la liste `Salaries`. Le numéro de sécurité sociale, les coordonnées bancaires et le salaire n'y figurent volontairement pas.
- **Effectifs et échéances** (Équipe > Effectifs) : effectif, équivalent temps plein, entrées et sorties, répartitions, et alertes de fin de période d'essai, de fin de contrat et de visite médicale.

Si l'outil était déjà installé avant la V4, ajoutez à la main la colonne `Details` (texte sur plusieurs lignes) à la liste `Salaries`.

### Export Silae

Le fichier `silae-AAAA-MM.csv` (séparateur point-virgule) contient cinq colonnes : `Matricule ; Code ; Valeur ; Date début ; Date fin`. Il comporte une ligne d'heures travaillées par salarié et une ligne par absence validée du mois.

Les codes par défaut (`HS-HN`, `AB-CP`, `AB-MAL`…) et l'ordre des colonnes sont des hypothèses : le format attendu dépend du paramétrage de votre dossier Silae. **Faites valider un premier fichier par la personne ou le cabinet qui gère la paie**, puis ajustez les codes dans `config.js`.

## Limites à connaître

- **Non testé sur un vrai Microsoft 365.** Tous les écrans et calculs ont été vérifiés en mode démonstration. La connexion Microsoft, les listes SharePoint, le dépôt de justificatifs et l'envoi d'e-mails n'ont pas pu être essayés : prévoyez un test avec deux ou trois comptes.
- **Protection des données.** Les membres du site peuvent techniquement ouvrir les listes et la bibliothèque dans SharePoint. Activez l'historique des versions sur les listes, et **restreignez l'accès au dossier `Justificatifs`** aux RH et aux managers. Pour un cloisonnement strict, il faudra un petit serveur intermédiaire.
- **Fiches salariés.** Elles contiennent désormais des données personnelles (adresse, date de naissance, personne à prévenir, dates de visite médicale). Or tout membre du site SharePoint peut ouvrir la liste `Salaries`. Avant de saisir de vraies données, restreignez les droits de cette liste aux RH et aux managers, ou prévoyez le serveur intermédiaire.
- **Heures supplémentaires.** Les majorations ne sont pas calculées ; seul l'écart débit-crédit est suivi.
- **Heure du pointage.** C'est l'heure de l'appareil du salarié qui est enregistrée.
- **Activité.** Une seule activité par journée.
- **RGPD.** Un outil de suivi du temps de travail doit figurer au registre des traitements, et les salariés ainsi que le CSE doivent en être informés avant sa mise en service.
